spring boot + jsp + bootstrap integration

URL - http://localhost:8080/mightyjava/