/*insert into "users"("id","user_name","password", "email", "full_name", "mobile", "user_id") values
(1, 'Tiago Lopes', '123456', 'tlopes@gmail.com', 'Tiago Lopes', '$2a$10$XBQ9jnH3tqdUSqeTRfvrQOFyZsqxPym29nGKrlyhYUUYU7jg9dvMC', 1),
(2, 'Tiago Santos', '123456', 'tlopes@gmail.com', 'Tiago Santos','$2a$10$XBQ9jnH3tqdUSqeTRfvrQOFyZsqxPym29nGKrlyhYUUYU7jg9dvMC',1);*/